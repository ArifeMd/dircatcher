DirFinder is a directory bruteforce script to find directories
in websites created by WhiteRaven for bug bounty hunters and 
security researcher.

How To Use:

    1. pip3 install -r requirements.txt
    
    2.python3 dirfinder.py -u [URL] -l [WORDLIST]

    Example: python3 dirfinder.py -u https://www.target.com -l wordlist.txt

If u face any kind of problem the tool, contact me:senguptatanay6@gmail.com
